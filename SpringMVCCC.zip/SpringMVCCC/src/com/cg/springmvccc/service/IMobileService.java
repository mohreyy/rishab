package com.cg.springmvccc.service;

import com.cg.springmvccc.dto.Mobile;

public interface IMobileService {
	public void addMobile(Mobile mobile);

}
