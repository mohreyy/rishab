package com.cg.springmvccc.dao;

import com.cg.springmvccc.dto.Mobile;

public interface IMobileDao {

public void addMobile(Mobile mobile);

}
